About Us
========

Core Development Team
"""""""""""""""""""""

Wenjie Du
**********
- Founded the organization in March 2022
- `GitHub (WenjieDu) <https://github.com/WenjieDu>`_
- `LinkedIn (Wenjie Du) <https://www.linkedin.com/in/wenjie-du>`_

Jun Wang
********
- Joined in August 2023
- `GitHub (AugustJW) <https://github.com/AugustJW>`_
- `LinkedIn (Jun Wang) <https://www.linkedin.com/in/wang-jun-35323b193>`_

Linglong Qian
*************
- Joined in February 2024
- `GitHub (LinglongQian) <https://github.com/LinglongQian>`_
- `LinkedIn (Linglong Qian) <https://www.linkedin.com/in/linglongqian>`_

Yiyuan Yang
************
- Joined in Jun 2024
- `GitHub (yyysjz1997) <https://github.com/yyysjz1997>`_
- `LinkedIn (Yiyuan Yang) <https://www.linkedin.com/in/yiyuan-yang-8154941ab/>`_


All Contributors
""""""""""""""""
PyPOTS exists thanks to all the nice people (sorted by contribution time) who contribute their time to work on the project (including the repositories
`PyPOTS <https://github.com/WenjieDu/PyPOTS/graphs/contributors>`_,
`BrewPOTS <https://github.com/WenjieDu/BrewPOTS/graphs/contributors>`_,
`TSDB <https://github.com/WenjieDu/TSDB/graphs/contributors>`_,
`PyGrinder <https://github.com/WenjieDu/PyGrinder/graphs/contributors>`_):

.. raw:: html

    <object data="https://pypots.com/figs/pypots_logos/publicity/PyPOTS_contributors.svg">
    </object>
