"""
The package of the classification model "Your model name".

Refer to the paper "Your paper citation".

TODO: modify the above description with your model's information.

"""

# Created by Your Name <Your contact email> TODO: modify the author information.
# License: BSD-3-Clause

# TODO: ensure the import is correct
from .model import YourNewModel

__all__ = [
    "YourNewModel",  # TODO: ensure the name is correct
]
